INSERT INTO students (roll_number, first_name, last_name, email, department, student_year, gpa)
VALUES ('IT18', 'Shraddha', 'Hebbar', 'shraddha@example.com', 'IT', 2, 8.5);

INSERT INTO students (roll_number, first_name, last_name, email, department, student_year, gpa)
VALUES ('BCA25', 'Karthik', 'Hebbar', 'karthik@example.com', 'BCA', 3, 7.9);
